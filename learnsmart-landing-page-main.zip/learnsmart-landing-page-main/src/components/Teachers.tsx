import { Star, Mail, Phone, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

const Teachers = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const teachers = [
    {
      name: "Dr. Rajesh Kumar",
      qualification: "M.Sc, Ph.D Physics",
      subject: "Physics & Mathematics",
      experience: "12 years",
      bio: "Expert in making complex physics concepts simple and understandable for students.",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&crop=face"
    },
    {
      name: "Prof. Anita Sharma",
      qualification: "M.Sc Chemistry, B.Ed",
      subject: "Chemistry",
      experience: "10 years",
      bio: "Passionate chemistry teacher with innovative teaching methods and excellent results.",
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1494790108755-2616b2e2fc16?w=300&h=300&fit=crop&crop=face"
    },
    {
      name: "Mr. Vikram Singh",
      qualification: "M.A English Literature",
      subject: "English",
      experience: "8 years",
      bio: "Dedicated to improving students' language skills and literary understanding.",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&crop=face"
    },
    {
      name: "Dr. Priya Patel",
      qualification: "M.Sc Biology, Ph.D",
      subject: "Biology & Life Sciences",
      experience: "15 years",
      bio: "Making biology interesting through practical examples and real-world applications.",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300&h=300&fit=crop&crop=face"
    }
  ];

  const nextTeacher = () => {
    setCurrentIndex((prev) => (prev + 1) % teachers.length);
  };

  const prevTeacher = () => {
    setCurrentIndex((prev) => (prev - 1 + teachers.length) % teachers.length);
  };

  return (
    <section id="teachers" className="section-padding bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-heading font-bold text-foreground mb-4">
            Meet Our <span className="text-gradient">Expert Teachers</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our qualified and experienced faculty members are dedicated to helping you achieve 
            your academic goals with personalized attention and innovative teaching methods.
          </p>
        </div>

        {/* Teachers Carousel - Desktop */}
        <div className="hidden lg:grid lg:grid-cols-2 xl:grid-cols-4 gap-6">
          {teachers.map((teacher, index) => (
            <div key={index} className="bg-card p-6 rounded-2xl card-hover text-center">
              {/* Teacher Image */}
              <div className="relative mb-6">
                <img
                  src={teacher.image}
                  alt={teacher.name}
                  className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-primary/20"
                />
                <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-secondary text-secondary-foreground px-3 py-1 rounded-full text-xs font-medium">
                  {teacher.experience}
                </div>
              </div>

              {/* Teacher Info */}
              <h3 className="text-xl font-heading font-semibold text-foreground mb-1">
                {teacher.name}
              </h3>
              <p className="text-primary font-medium mb-2">{teacher.qualification}</p>
              <p className="text-muted-foreground text-sm mb-3">{teacher.subject}</p>
              
              {/* Rating */}
              <div className="flex items-center justify-center mb-4">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(teacher.rating) ? "text-secondary fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                  <span className="text-sm text-muted-foreground ml-2">({teacher.rating})</span>
                </div>
              </div>

              {/* Bio */}
              <p className="text-muted-foreground text-sm mb-6 leading-relaxed">
                {teacher.bio}
              </p>

              {/* CTA */}
              <a href="#contact" className="btn-outline text-sm">
                Book Trial Class
              </a>
            </div>
          ))}
        </div>

        {/* Teachers Carousel - Mobile */}
        <div className="lg:hidden">
          <div className="relative">
            {/* Current Teacher Card */}
            <div className="bg-card p-6 rounded-2xl text-center">
              <div className="relative mb-6">
                <img
                  src={teachers[currentIndex].image}
                  alt={teachers[currentIndex].name}
                  className="w-32 h-32 rounded-full mx-auto object-cover border-4 border-primary/20"
                />
                <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-secondary text-secondary-foreground px-3 py-1 rounded-full text-xs font-medium">
                  {teachers[currentIndex].experience}
                </div>
              </div>

              <h3 className="text-xl font-heading font-semibold text-foreground mb-1">
                {teachers[currentIndex].name}
              </h3>
              <p className="text-primary font-medium mb-2">{teachers[currentIndex].qualification}</p>
              <p className="text-muted-foreground text-sm mb-3">{teachers[currentIndex].subject}</p>
              
              <div className="flex items-center justify-center mb-4">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(teachers[currentIndex].rating) ? "text-secondary fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                  <span className="text-sm text-muted-foreground ml-2">({teachers[currentIndex].rating})</span>
                </div>
              </div>

              <p className="text-muted-foreground text-sm mb-6 leading-relaxed">
                {teachers[currentIndex].bio}
              </p>

              <a href="#contact" className="btn-outline">
                Book Trial Class
              </a>
            </div>

            {/* Navigation Arrows */}
            <button
              onClick={prevTeacher}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-card p-2 rounded-full shadow-lg"
            >
              <ChevronLeft className="w-5 h-5 text-primary" />
            </button>
            <button
              onClick={nextTeacher}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-card p-2 rounded-full shadow-lg"
            >
              <ChevronRight className="w-5 h-5 text-primary" />
            </button>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center mt-6 space-x-2">
            {teachers.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                  index === currentIndex ? "bg-primary" : "bg-border"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Teachers;