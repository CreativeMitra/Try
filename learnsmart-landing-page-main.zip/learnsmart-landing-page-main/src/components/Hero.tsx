import { Play, BookOpen, Users, Trophy, ArrowRight } from "lucide-react";
import heroImage from "@/assets/hero-education.jpg";

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Students learning in modern classroom"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-primary/80"></div>
      </div>

      {/* Floating Icons */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <BookOpen className="absolute top-20 left-10 w-8 h-8 text-secondary/30 float" style={{ animationDelay: '0s' }} />
        <Trophy className="absolute top-32 right-20 w-6 h-6 text-secondary/20 float" style={{ animationDelay: '1s' }} />
        <Users className="absolute bottom-32 left-20 w-10 h-10 text-secondary/25 float" style={{ animationDelay: '2s' }} />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Trust Badges */}
          <div className="flex flex-wrap justify-center gap-6 mb-8 fade-in">
            <div className="flex items-center space-x-2 text-secondary">
              <Users className="w-5 h-5" />
              <span className="text-sm font-medium">1000+ Students Taught</span>
            </div>
            <div className="flex items-center space-x-2 text-secondary">
              <Trophy className="w-5 h-5" />
              <span className="text-sm font-medium">10+ Years Experience</span>
            </div>
          </div>

          {/* Main Headline */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6 hero-text-shadow fade-in-up" style={{ animationDelay: '0.2s' }}>
            Achieve Academic{" "}
            <span className="text-secondary">Excellence</span>
            <br />
            with Expert Tutors
          </h1>

          {/* Subheadline */}
          <p className="text-xl md:text-2xl text-white/90 mb-8 fade-in-up" style={{ animationDelay: '0.4s' }}>
            Personalized coaching for Grades 6 to 12 & Competitive Exams
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 fade-in-up" style={{ animationDelay: '0.6s' }}>
            <a href="#contact" className="btn-secondary text-lg px-8 py-4">
              <Play className="w-5 h-5" />
              Book Free Trial
            </a>
            <a href="#about" className="btn-outline text-lg px-8 py-4 text-white border-white hover:bg-white hover:text-primary">
              <ArrowRight className="w-5 h-5" />
              Learn More
            </a>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto fade-in-up" style={{ animationDelay: '0.8s' }}>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="text-3xl font-bold text-secondary mb-2">10+</div>
              <div className="text-white/90">Expert Tutors</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="text-3xl font-bold text-secondary mb-2">500+</div>
              <div className="text-white/90">Happy Students</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="text-3xl font-bold text-secondary mb-2">90%</div>
              <div className="text-white/90">Success Rate</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;